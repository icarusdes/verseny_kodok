
#ifndef LIB_H
#define LIB_H

int libfn1();
int libfn2(int b);

#endif /* LIB_H */

