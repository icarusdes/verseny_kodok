#ifndef LONGFUNC_H
#define LONGFUNC_H

int long_function(int i);

#endif /* LONGFUNC_H */
