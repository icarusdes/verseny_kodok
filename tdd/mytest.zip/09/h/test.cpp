
#include "lib.h"

int main ()
{
     libfn1();
     libfn2(5);
}
